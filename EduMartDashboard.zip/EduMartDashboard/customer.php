<?php
if (isset($_POST['addCustomer'])) {
  $mysqli = new mysqli("localhost", "root", "", "edumart");
  if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
  }
  $name = $_POST['name'];
  $email = $_POST['email'];
  $country = $_POST['country'];
  $date = $_POST['date'];
  $status = $_POST['status'];
  $stmt = $mysqli->prepare("INSERT INTO customers (name, email, country, date, status) VALUES (?, ?, ?, ?, ?)");
  $stmt->bind_param("sssss", $name, $email, $country, $date, $status);
  if ($stmt->execute()) {
    echo "<script>alert('Customer added successfully'); window.location.href = window.location.href;</script>";
  } else {
    echo "<script>alert('Failed to add customer');</script>";
  }
  $stmt->close();
  $mysqli->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>EduMart - Customers</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-50 text-gray-800 font-sans">
  <div class="flex">
    <!-- Sidebar -->
    <aside class="w-64 h-screen bg-white border-r p-4">
      <div class="text-xl font-bold mb-6 flex items-center space-x-2">
        <img src="images/techora.jpg" alt="EduMart Logo" class="w-8 h-8 rounded-full"/>
        <span>EduMart</span>
      </div>
      <nav class="space-y-4 text-sm">
        <div>
          <p class="text-gray-500 uppercase">Main</p>
          <ul class="space-y-2">
            <li><a href="#" class="flex items-center space-x-2 bg-purple-600 text-white px-2 py-1 rounded"><span>🏠</span><span>Dashboard</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>📦</span><span>Orders</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>📋</span><span>Products</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>👥</span><span>Buyer</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>👨‍💼</span><span>Customers</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>📄</span><span>Invoices</span></a></li>
          </ul>
        </div>

        <div>
          <p class="text-gray-500 uppercase">Apps</p>
          <ul class="space-y-2">
            <li><a href="#" class="flex items-center space-x-2"><span>💬</span><span>Chats</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>📧</span><span>Email</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>📝</span><span>Todo App</span></a></li>
          </ul>
        </div>

        <div>
          <p class="text-gray-500 uppercase">Pages</p>
          <ul class="space-y-2">
            <li><a href="#" class="flex items-center space-x-2"><span>👤</span><span>Profile</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>🔒</span><span>Users</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>🔑</span><span>Authentication</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>❌</span><span>Error Pages</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>⚙️</span><span>Settings</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>💰</span><span>Pricing Table</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>🔍</span><span>Search Page</span></a></li>
            <li><a href="#" class="flex items-center space-x-2"><span>❓</span><span>FAQ</span></a></li>
          </ul>
        </div>
      </nav>
    </aside>

    <!-- Main content -->
    <!-- (unchanged from earlier, already working) -->


    <!-- Main content -->
    <main class="flex-1 p-6">
      <header class="flex justify-between items-center mb-6">
        <div>
          <h1 class="text-xl font-semibold">Customers</h1>
          <nav class="text-sm text-gray-500">Dashboard / Customers</nav>
        </div>
        <div>
          <button onclick="openModal()" class="bg-purple-600 text-white px-4 py-2 rounded">➕ Add Customers</button>
        </div>
      </header>

      <!-- Chart + Rating -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div class="md:col-span-2 bg-white p-4 rounded shadow">
          <h2 class="text-md font-semibold mb-2">New Customers</h2>
          <canvas id="customerChart" height="120"></canvas>
        </div>
        <div class="bg-white p-4 rounded shadow flex flex-col justify-between">
          <div>
            <h2 class="text-md font-semibold mb-2">Customer Rating</h2>
            <p class="text-3xl font-bold">4.5</p>
            <p class="text-yellow-500 text-xl">⭐⭐⭐⭐⭐</p>
            <p class="text-green-500 text-sm mt-1">+35 Point from last month</p>
          </div>
          <button class="mt-4 bg-purple-600 text-white px-4 py-2 rounded text-sm">⬇ Download Report</button>
        </div>
      </div>

      <!-- Customer Table -->
      <div class="bg-white p-4 rounded shadow">
        <table class="min-w-full text-sm">
          <thead class="bg-gray-100 text-left">
            <tr>
              <th class="p-2">ID</th>
              <th class="p-2">Photo</th>
              <th class="p-2">Full Name</th>
              <th class="p-2">Email</th>
              <th class="p-2">Country</th>
              <th class="p-2">Date</th>
              <th class="p-2">Status</th>
              <th class="p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $mysqli = new mysqli("localhost", "root", "", "edumart");
              if ($mysqli->connect_error) {
                die("Connection failed: " . $mysqli->connect_error);
              }
              $sql = "SELECT * FROM customers ORDER BY id DESC";
              $result = $mysqli->query($sql);
              while($row = $result->fetch_assoc()) {
                $initial = strtoupper(substr($row['name'], 0, 1));
                $statusClass = $row['status'] === 'active' ? 'bg-green-200 text-green-800' : 'bg-red-200 text-red-800';
                echo "<tr class='border-b'>
                        <td class='p-2'>#{$row['id']}</td>
                        <td class='p-2'>
                          <div class='w-8 h-8 rounded-full bg-purple-400 text-white flex items-center justify-center'>{$initial}</div>
                        </td>
                        <td class='p-2'>{$row['name']}</td>
                        <td class='p-2'>{$row['email']}</td>
                        <td class='p-2'>{$row['country']}</td>
                        <td class='p-2'>{$row['date']}</td>
                        <td class='p-2'><span class='px-2 py-1 rounded-full text-xs font-semibold {$statusClass}'>" . ucfirst($row['status']) . "</span></td>
                        <td class='p-2 text-gray-400'>...</td>
                      </tr>";
              }
              $mysqli->close();
            ?>
          </tbody>
        </table>
      </div>
    </main>
  </div>

  <!-- Modal Form -->
  <div id="addModal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-40 hidden z-50">
    <div class="bg-white p-6 rounded shadow w-full max-w-md">
      <h2 class="text-lg font-semibold mb-4">Add New Customer</h2>
      <form method="POST" action="" class="space-y-4">
        <input name="name" type="text" placeholder="Full Name" class="w-full border p-2 rounded" required />
        <input name="email" type="email" placeholder="Email" class="w-full border p-2 rounded" required />
        <input name="country" type="text" placeholder="Country" class="w-full border p-2 rounded" required />
        <input name="date" type="date" class="w-full border p-2 rounded" required />
        <select name="status" class="w-full border p-2 rounded" required>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
        <div class="flex justify-end space-x-2">
          <button type="button" onclick="closeModal()" class="px-4 py-2 border rounded">Cancel</button>
          <button type="submit" name="addCustomer" class="bg-purple-600 text-white px-4 py-2 rounded">Add</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    function openModal() {
      document.getElementById('addModal').classList.remove('hidden');
    }
    function closeModal() {
      document.getElementById('addModal').classList.add('hidden');
    }

    const ctx = document.getElementById('customerChart').getContext('2d');
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['01 Jan', '02 Jan', '03 Jan', '04 Jan', '05 Jan', '06 Jan', '07 Jan'],
        datasets: [{
          label: 'Customers',
          data: [40, 60, 80, 70, 60, 90, 100],
          borderColor: 'orange',
          fill: false
        }]
      },
      options: { responsive: true }
    });
  </script>
</body>
</html>
