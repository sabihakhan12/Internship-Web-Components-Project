<?php
// Enable PHP error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if form is submitted via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form fields
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $message = $_POST['message'] ?? '';

    // Basic validation
    if (!empty($name) && !empty($email) && !empty($subject) && !empty($message)) {
        // Database settings
        $host = "localhost";
        $user = "root";
        $password = "";
        $dbname = "edumart";

        // Connect
        $conn = new mysqli($host, $user, $password, $dbname);
        if ($conn->connect_error) {
            die("DB connection failed: " . $conn->connect_error);
        }

        // Insert query
        $sql = "INSERT INTO contact_messages (name, email, subject, message) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssss", $name, $email, $subject, $message);

        if ($stmt->execute()) {
            echo "<script>alert('Message sent successfully!'); window.location.href='contact.html';</script>";
        } else {
            echo "DB Insert Error: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    } else {
        echo "Error: All fields are required.";
    }
} else {
    echo "Error: Invalid request.";
}
?>
