// script.js

// Handle form submission with a simple alert
document.getElementById("contactForm").addEventListener("submit", function (e) {
  e.preventDefault();

  // You could add form validation here if needed

  alert("Your message has been sent! (Note: This is a frontend-only form.)");

  // Optional: Reset form fields
  this.reset();
});
