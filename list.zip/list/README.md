# 📋 EduMart - Orders List Page

Yeh ek full working orders list page hai jo banaya gaya hai PHP, MySQL, Tailwind CSS aur XAMPP ka use karke.

Yeh modern admin panel jaisa design deta hai jisme sidebar, search bar aur colored status badges hain.

---

## 📁 Folder Structure


2. **XAMPP ko open karo:**
- Apache ko **Start** karo ✅
- MySQL ko **Start** karo ✅

3. **Database import karo:**

- Browser me jao: `http://localhost/phpmyadmin`
- "Import" tab pe jao
- `edumart.sql` file upload karo
- Is se `edumart` database aur `orders` table ban jaayega

4. **db.php file check karo:**

```php
<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "edumart"; // Yahan pe database ka naam likhna hai
$conn = new mysqli($host, $user, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>


http://localhost/list/list.php
