<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>EduMart - Orders List</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">

<div class="flex">
  <!-- Sidebar -->
  <div class="w-64 min-h-screen bg-white shadow">
    <div class="p-6 flex items-center space-x-2">
      <img src="techora.jpg" class="h-10 w-10 rounded-full" />
      <span class="font-bold text-lg">EduMart</span>
    </div>
    <nav class="mt-4">
      <ul class="space-y-2">
        <li><a href="#" class="block px-6 py-2 hover:bg-gray-200">Dashboard</a></li>
        <li>
          <span class="block px-6 py-2 font-bold text-purple-700">Orders</span>
          <ul class="pl-6">
            <li><a href="#" class="block px-6 py-2 bg-purple-100 text-purple-700 rounded">List</a></li>
            <li><a href="#" class="block px-6 py-2 hover:bg-gray-200">Detail</a></li>
          </ul>
        </li>
        <li><a href="#" class="block px-6 py-2 hover:bg-gray-200">Products</a></li>
        <li><a href="#" class="block px-6 py-2 hover:bg-gray-200">Buyer</a></li>
        <li><a href="#" class="block px-6 py-2 hover:bg-gray-200">Customers</a></li>
        <li><a href="#" class="block px-6 py-2 hover:bg-gray-200">Invoices</a></li>
      </ul>
    </nav>
  </div>

  <!-- Main Content -->
  <div class="flex-1 p-6">
    <div class="flex justify-between items-center mb-6">
      <h1 class="text-2xl font-bold">Orders</h1>
      <input type="text" id="search" placeholder="Search..." class="border rounded px-4 py-2 w-64">
    </div>

    <table class="min-w-full bg-white rounded shadow">
      <thead>
        <tr class="bg-gray-200 text-left text-sm font-semibold text-gray-700">
          <th class="px-6 py-3">ID</th>
          <th class="px-6 py-3">Name</th>
          <th class="px-6 py-3">Date</th>
          <th class="px-6 py-3">Total</th>
          <th class="px-6 py-3">Status</th>
        </tr>
      </thead>
      <tbody id="ordersTable" class="text-sm text-gray-600">
        <?php
        $result = $conn->query("SELECT * FROM orders ORDER BY id DESC");
        while ($row = $result->fetch_assoc()) {
          $statusColor = '';
          switch ($row['status']) {
            case 'Processing':
              $statusColor = 'bg-orange-500';
              break;
            case 'Shipped':
              $statusColor = 'bg-gray-800';
              break;
            case 'Completed':
              $statusColor = 'bg-green-500';
              break;
            case 'Refunded':
              $statusColor = 'bg-yellow-400';
              break;
            case 'Cancelled':
              $statusColor = 'bg-red-500';
              break;
            default:
              $statusColor = 'bg-gray-300';
          }

          echo "<tr class='border-b'>";
          echo "<td class='px-6 py-4'>{$row['order_id']}</td>";
          echo "<td class='px-6 py-4'>{$row['name']}</td>";
          echo "<td class='px-6 py-4'>" . date("M d, Y", strtotime($row['date'])) . "</td>";
          echo "<td class='px-6 py-4'>$" . number_format($row['total'], 2) . "</td>";
          echo "<td class='px-6 py-4'><span class='px-3 py-1 rounded-full text-white text-xs {$statusColor}'>{$row['status']}</span></td>";
          echo "</tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</div>

<script>
  const searchInput = document.getElementById("search");
  searchInput.addEventListener("input", function () {
    const filter = searchInput.value.toLowerCase();
    const rows = document.querySelectorAll("#ordersTable tr");
    rows.forEach(row => {
      const text = row.innerText.toLowerCase();
      row.style.display = text.includes(filter) ? "" : "none";
    });
  });
</script>

</body>
</html>
