<?php
$host = "localhost";
$user = "root";
$password = "";  // leave blank in XAMPP
$database = "jinstore";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
