<?php
include 'db/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first = $_POST['first_name'];
    $last = $_POST['last_name'];
    $shop = $_POST['shop_name'];
    $url = $_POST['shop_url'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];

    $sql = "INSERT INTO vendors (first_name, last_name, shop_name, shop_url, email, phone)
            VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $first, $last, $shop, $url, $email, $phone);

    if ($stmt->execute()) {
        echo "Vendor registered successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>
